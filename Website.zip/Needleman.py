import json 
s1 = "CGTA"
s2 = "C"

p = 2
n = -2
g = -3

matrix = []

height = 0
width = 0


def Needleman_Wunsch():
    #						Needleman_Wunsch method
    
    #						Making the blank matrix
    for x in range(height+2):
        matrix.append([])
        for y in range(width+2):
            matrix[x].append('')# will be set to null after testing
        
    #						Giving it starter values
    matrix[1][1] = 0
    matrix[1][2] = g
    matrix[2][1] = g
    #						Making the first collumn and line
    for x in range(height+2):
        if x>1:
            matrix[x][1] = matrix[x-1][1] + g
            matrix[x][0] = s2[x-2]
    for y in range(width+2):
        if y>1:
            matrix[1][y] = matrix[1][y-1] + g
            matrix[0][y] = s1[y-2]
            
    #						Calculating the matrix
    for x in range(height+2):
        for y in range(width+2):
            if x>1 and y>1:#Getting into the main part
    #						Diagonal line
                maxi=0
                if x==y:
                    matrix[x][y]=matrix[x-1][y-1] + png_test(x,y)
    #						The rest
                else:
                    maxi=max(matrix[x-1][y],matrix[x][y-1],matrix[x-1][y-1])
                    matrix[x][y]=maxi + png_test(x,y)

def show_matrix():
    for x in range(height+2):
        print('\n')
        for y in range(width+2):
            print(matrix[x][y],end=' ')

def dl_dh():
    #						Shows the 'score' of the matrix
    line_min = min(height,width)
    line_max = max(height,width)
    dh = 0
    dl = 0
    nn = 0
    for x in range(line_min):
        if s1[x-1]==s2[x-1]:
            dh += 1
        else:
            nn += 1
    dl = dh*p + nn*n + (line_max-line_min)*g	
    print("\nDH = ",dh)
    print("DL = ",dl)

def png_test(x,y):
    x=x-2
    y=y-2
    
    if s1[y]==s2[x]:
        return p
    elif x==y:
        return n
    else:
        return g
    #						Initialising the basic vars
if s1 and s2:
    width = len(s1)
    height = len(s2)
    #						Erases any previous values
    #						matrix = []
    #						Starts processes
Needleman_Wunsch()
show_matrix()
dl_dh()
x = json.dumps(matrix)

with open("sample.json", "w") as outfile:
    outfile.write(x)